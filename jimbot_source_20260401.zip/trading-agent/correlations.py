"""
correlations.py — Inter-Asset Correlation Intelligence
Detects correlation breakdowns, relative strength signals, and beta-adjusted sizing.
The most powerful edge most retail bots completely miss.
"""
import logging
from datetime import datetime, timezone
from typing import Optional
import requests

logger = logging.getLogger(__name__)

# ── Correlation matrix (static knowledge) ────────────────────────────────────

# Expected correlation direction between asset pairs
# 1.0 = perfectly correlated, -1.0 = perfectly inverse
CORRELATION_MATRIX = {
    ("BTC/USD", "ETH/USD"):   0.88,
    ("BTC/USD", "SOL/USD"):   0.82,
    ("BTC/USD", "AVAX/USD"):  0.80,
    ("BTC/USD", "DOGE/USD"):  0.75,
    ("BTC/USD", "LINK/USD"):  0.78,
    ("BTC/USD", "XRP/USD"):   0.72,
    ("ETH/USD", "SOL/USD"):   0.85,
    ("BTC/USD", "QQQ"):       0.72,
    ("BTC/USD", "SPY"):       0.65,
    ("NVDA",    "AMD"):       0.80,
    ("NVDA",    "QQQ"):       0.75,
    ("TSLA",    "BTC/USD"):   0.60,
    ("AAPL",    "QQQ"):       0.85,
    ("META",    "GOOGL"):     0.78,
}

# Beta coefficients (how much more volatile vs BTC or NASDAQ)
BETA = {
    "BTC/USD":  1.0,
    "ETH/USD":  1.1,
    "SOL/USD":  1.8,
    "AVAX/USD": 2.0,
    "DOGE/USD": 2.5,
    "LINK/USD": 1.9,
    "XRP/USD":  1.7,
    "SHIB/USD": 3.0,
    "TSLA":     1.5,
    "NVDA":     1.8,
    "AMD":      1.6,
    "META":     1.3,
    "GOOGL":    1.1,
    "AAPL":     1.0,
    "MSFT":     1.0,
    "QQQ":      1.0,
    "SPY":      0.8,
    "ARKK":     2.2,
}

# Sector groupings — never hold more than 2 from same sector
SECTORS = {
    "crypto_large":    ["BTC/USD", "ETH/USD"],
    "crypto_mid":      ["SOL/USD", "AVAX/USD", "LINK/USD", "XRP/USD"],
    "crypto_meme":     ["DOGE/USD", "SHIB/USD"],
    "semis":           ["NVDA", "AMD"],
    "big_tech":        ["AAPL", "MSFT", "GOOGL", "META"],
    "etf_broad":       ["QQQ", "SPY"],
    "etf_speculative": ["ARKK"],
    "ev_disruptive":   ["TSLA"],
}


class CorrelationIntelligence:
    """
    Monitors inter-asset correlations in real-time.
    Detects breakdowns (relative strength signals) and enforces diversification.
    """

    # Expose module-level dict for use via self.CORRELATION_MATRIX
    CORRELATION_MATRIX = CORRELATION_MATRIX

    def __init__(self):
        self._price_cache: dict = {}
        self._cache_time: Optional[datetime] = None
        logger.info("✅ CorrelationIntelligence initialized")

    # ── Price fetching ────────────────────────────────────────────────────────

    def _fetch_current_change(self, symbol: str) -> Optional[float]:
        """Fetch today's % change for a symbol via Yahoo Finance."""
        try:
            yf_symbol = symbol.replace("/", "-")
            url = f"https://query1.finance.yahoo.com/v8/finance/chart/{yf_symbol}?interval=1d&range=2d"
            headers = {"User-Agent": "Mozilla/5.0"}
            resp = requests.get(url, headers=headers, timeout=5)
            data = resp.json()
            closes = data["chart"]["result"][0]["indicators"]["quote"][0]["close"]
            closes = [c for c in closes if c is not None]
            if len(closes) < 2:
                return None
            change = (closes[-1] - closes[-2]) / closes[-2] * 100
            return round(change, 3)
        except Exception:
            return None

    def refresh_prices(self, symbols: list) -> dict:
        """
        Fetch % change for a list of symbols.
        Caches for 5 minutes.
        """
        now = datetime.now(timezone.utc)
        if self._cache_time:
            age = (now - self._cache_time).total_seconds()
            if age < 300 and self._price_cache:
                return self._price_cache

        changes = {}
        for sym in symbols:
            chg = self._fetch_current_change(sym)
            if chg is not None:
                changes[sym] = chg

        self._price_cache = changes
        self._cache_time = now
        logger.info(f"📊 Correlation prices refreshed: {len(changes)} symbols")
        return changes

    # ── Relative strength detection ───────────────────────────────────────────

    def detect_relative_strength(self, symbol: str, changes: dict) -> dict:
        """
        Detect if a symbol is showing relative strength or weakness vs correlated peers.

        BULLISH signal: Asset holds flat or rises while correlated peers fall.
        BEARISH signal: Asset falls while correlated peers rise.

        This is one of the highest-conviction signals in trading.
        """
        if symbol not in changes:
            return {"signal": "neutral", "score_adjustment": 0, "reason": "No price data"}

        asset_change = changes[symbol]
        correlated_peers = []

        # Find correlated peers
        for (a, b), corr in CORRELATION_MATRIX.items():
            if corr >= 0.7:  # Only strong correlations
                if a == symbol and b in changes:
                    correlated_peers.append((b, changes[b], corr))
                elif b == symbol and a in changes:
                    correlated_peers.append((a, changes[a], corr))

        if not correlated_peers:
            return {"signal": "neutral", "score_adjustment": 0, "reason": "No correlated peers available"}

        avg_peer_change = sum(c for _, c, _ in correlated_peers) / len(correlated_peers)
        divergence = asset_change - avg_peer_change

        # Relative strength threshold: asset outperforms peers by >1.5%
        if divergence > 1.5:
            signal = "relative_strength_bullish"
            score_adjustment = +20
            reason = f"{symbol} +{asset_change:.1f}% vs peers avg {avg_peer_change:.1f}% — strong buyer absorption"
        elif divergence > 0.8:
            signal = "mild_strength"
            score_adjustment = +10
            reason = f"{symbol} outperforming peers by {divergence:.1f}%"
        elif divergence < -1.5:
            signal = "relative_weakness_bearish"
            score_adjustment = -20
            reason = f"{symbol} {asset_change:.1f}% vs peers avg {avg_peer_change:.1f}% — selling pressure"
        elif divergence < -0.8:
            signal = "mild_weakness"
            score_adjustment = -10
            reason = f"{symbol} underperforming peers by {abs(divergence):.1f}%"
        else:
            signal = "neutral"
            score_adjustment = 0
            reason = f"{symbol} moving in line with peers"

        return {
            "signal": signal,
            "score_adjustment": score_adjustment,
            "reason": reason,
            "asset_change": asset_change,
            "peer_avg_change": round(avg_peer_change, 3),
            "divergence": round(divergence, 3),
            "peers": [(p, round(c, 3)) for p, c, _ in correlated_peers],
        }

    # ── DXY impact for crypto ─────────────────────────────────────────────────

    def get_dxy_crypto_adjustment(self, dxy_trend: str) -> dict:
        """
        DXY trend impact on crypto longs.
        Rising DXY = bad for crypto. Falling DXY = good for crypto.
        """
        if dxy_trend == "rising":
            return {
                "adjustment": -15,
                "reason": "DXY rising — historically bearish for crypto (inverse correlation -75%)",
            }
        elif dxy_trend == "falling":
            return {
                "adjustment": +10,
                "reason": "DXY falling — historically bullish for crypto",
            }
        return {"adjustment": 0, "reason": "DXY neutral"}

    # ── Correlation filter for open positions ─────────────────────────────────

    def check_correlation_conflict(self, new_symbol: str, open_positions: list) -> dict:
        """
        Check if opening a new position would create dangerous correlation overlap
        with existing open positions.
        Returns warning if conflict detected.
        """
        if not open_positions:
            return {"conflict": False, "reason": "No open positions"}

        conflicts = []
        for open_sym in open_positions:
            corr = self.CORRELATION_MATRIX.get(
                (new_symbol, open_sym),
                self.CORRELATION_MATRIX.get((open_sym, new_symbol), 0)
            )
            if corr >= 0.80:
                conflicts.append((open_sym, corr))

        # Check sector overlap
        new_sector = self._get_sector(new_symbol)
        sector_count = sum(
            1 for s in open_positions
            if self._get_sector(s) == new_sector and new_sector != "unknown"
        )

        if conflicts:
            worst = max(conflicts, key=lambda x: x[1])
            return {
                "conflict": True,
                "score_adjustment": -20,
                "reason": (
                    f"High correlation conflict: {new_symbol} vs {worst[0]} "
                    f"({worst[1]:.0%} corr). Diversify."
                ),
                "conflicts": conflicts,
            }

        if sector_count >= 2:
            return {
                "conflict": True,
                "score_adjustment": -10,
                "reason": f"Sector concentration: already holding {sector_count} {new_sector} positions.",
            }

        return {"conflict": False, "score_adjustment": 0, "reason": "No correlation conflicts"}

    def _get_sector(self, symbol: str) -> str:
        for sector, symbols in SECTORS.items():
            if symbol in symbols:
                return sector
        return "unknown"

    # ── Beta-adjusted position sizing ─────────────────────────────────────────

    def get_beta_adjusted_size(self, symbol: str, base_size_pct: float, regime: str) -> float:
        """
        Adjust position size based on asset beta and current regime.
        High beta assets get smaller positions in bear/choppy regimes.
        High beta assets get normal positions in bull regime.
        """
        beta = BETA.get(symbol, 1.0)

        if regime in ["bear", "choppy"]:
            if beta > 2.0:
                adjusted = base_size_pct * 0.4
                logger.info(f"⚠️ {symbol} beta={beta} in {regime} regime → size reduced to {adjusted:.1f}%")
            elif beta > 1.5:
                adjusted = base_size_pct * 0.6
            elif beta > 1.2:
                adjusted = base_size_pct * 0.8
            else:
                adjusted = base_size_pct
        elif regime == "panic":
            adjusted = base_size_pct * 0.3
        else:
            # Bull regime: full size, slight bonus for high beta (more upside)
            if beta > 1.5:
                adjusted = min(base_size_pct * 1.1, 40.0)  # Cap at 40%
            else:
                adjusted = base_size_pct

        return round(adjusted, 1)

    # ── Context for Claude prompt ─────────────────────────────────────────────

    def build_correlation_context(
        self,
        symbol: str,
        open_positions: list,
        changes: dict,
        dxy_trend: str = "neutral"
    ) -> str:
        """
        Build a correlation intelligence summary for Claude's prompt.
        """
        rel_strength   = self.detect_relative_strength(symbol, changes)
        corr_conflict  = self.check_correlation_conflict(symbol, open_positions)
        dxy_impact     = self.get_dxy_crypto_adjustment(dxy_trend)

        is_crypto = "/" in symbol

        lines = ["=== CORRELATION INTELLIGENCE ==="]

        # Relative strength
        signal = rel_strength["signal"]
        emoji = "🟢" if "bullish" in signal else "🔴" if "bearish" in signal else "⚪"
        lines.append(f"Relative strength: {emoji} {signal.upper()}")
        lines.append(f"  → {rel_strength['reason']}")
        if rel_strength.get("peers"):
            peer_str = ", ".join([f"{p}: {c:+.1f}%" for p, c in rel_strength["peers"][:3]])
            lines.append(f"  Peers: {peer_str}")

        # DXY impact (crypto only)
        if is_crypto and dxy_impact["adjustment"] != 0:
            lines.append(f"DXY impact: {dxy_impact['reason']}")

        # Correlation conflicts
        if corr_conflict["conflict"]:
            lines.append(f"⚠️ CORRELATION CONFLICT: {corr_conflict['reason']}")
        else:
            lines.append("✅ No correlation conflicts with open positions")

        # Score summary
        total_adj = (
            rel_strength["score_adjustment"]
            + (dxy_impact["adjustment"] if is_crypto else 0)
            + corr_conflict.get("score_adjustment", 0)
        )
        lines.append(f"Total correlation score adjustment: {total_adj:+d}")

        return "\n".join(lines)
