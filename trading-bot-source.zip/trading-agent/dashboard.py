import hashlib
import hmac
import json
import logging
import os
import secrets
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from typing import Optional
from flask import Flask, jsonify, make_response, redirect, render_template_string, request, url_for
from flask_cors import CORS
import config
from memory import TradingMemory

logger = logging.getLogger(__name__)
app = Flask(__name__)
CORS(app)
app.secret_key = os.getenv("SESSION_SECRET", secrets.token_hex(32))

_memory: Optional[TradingMemory] = None
_regime  = None

# ── Auth helpers ───────────────────────────────────────────────────────────────
_AUTH_COOKIE   = "jb_session"
_SESSION_DAYS  = 30

def _dashboard_password() -> str:
    return os.getenv("DASHBOARD_PASSWORD", "")

def _sign_token(payload: str) -> str:
    key = app.secret_key.encode() if isinstance(app.secret_key, str) else app.secret_key
    sig = hmac.new(key, payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}"

def _verify_token(token: str) -> bool:
    if not token or "." not in token:
        return False
    payload, _, sig = token.rpartition(".")
    expected = hmac.new(
        app.secret_key.encode() if isinstance(app.secret_key, str) else app.secret_key,
        payload.encode(), hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, sig)

def _is_authenticated() -> bool:
    # Requêtes internes depuis localhost (proxy api-server) → toujours autorisées
    if request.remote_addr in ("127.0.0.1", "::1"):
        return True
    token = request.cookies.get(_AUTH_COOKIE, "")
    return bool(token) and _verify_token(token)

_PUBLIC_PATHS = {"/login", "/favicon.ico"}

@app.before_request
def require_auth():
    if request.path in _PUBLIC_PATHS or request.path.startswith("/static"):
        return
    if not _is_authenticated():
        if request.path.startswith("/api/"):
            return jsonify({"error": "unauthorized"}), 401
        return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        pwd = request.form.get("password", "")
        expected = _dashboard_password()
        if expected and hmac.compare_digest(
            hashlib.sha256(pwd.encode()).hexdigest(),
            hashlib.sha256(expected.encode()).hexdigest(),
        ):
            token   = _sign_token(secrets.token_hex(24))
            resp    = make_response(redirect(url_for("dashboard")))
            expires = datetime.now(timezone.utc) + timedelta(days=_SESSION_DAYS)
            resp.set_cookie(
                _AUTH_COOKIE, token,
                httponly=True, samesite="Lax",
                expires=expires, max_age=_SESSION_DAYS * 86400,
            )
            return resp
        error = "Mot de passe incorrect."
    return render_template_string(_LOGIN_HTML, error=error)

@app.route("/logout")
def logout():
    resp = make_response(redirect(url_for("login")))
    resp.delete_cookie(_AUTH_COOKIE)
    return resp

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Jim Bot — Login</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080c10;color:#c8d6e5;font-family:'Space Mono',monospace,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#0d1117;border:1px solid #1a2030;border-radius:12px;padding:40px 36px;
      width:100%;max-width:360px;text-align:center}
.logo{font-size:22px;font-weight:800;letter-spacing:.15em;color:#00ff88;
      text-transform:uppercase;margin-bottom:8px}
.sub{font-size:11px;color:#4a5568;margin-bottom:28px;letter-spacing:.05em}
input[type=password]{width:100%;padding:12px 14px;background:#080c10;border:1px solid #1a2030;
  border-radius:8px;color:#c8d6e5;font-family:inherit;font-size:13px;margin-bottom:14px;
  outline:none;transition:border .2s}
input[type=password]:focus{border-color:#00ff88}
button{width:100%;padding:12px;background:#00ff88;color:#080c10;border:none;border-radius:8px;
  font-family:inherit;font-size:13px;font-weight:700;letter-spacing:.08em;cursor:pointer;
  text-transform:uppercase;transition:opacity .2s}
button:hover{opacity:.85}
.error{color:#ff3860;font-size:11px;margin-bottom:12px}
</style>
</head>
<body>
<div class="card">
  <div class="logo">📐 Jim Bot</div>
  <div class="sub">Geo V4 — ETH/USD · Accès restreint</div>
  {% if error %}<div class="error">{{ error }}</div>{% endif %}
  <form method="POST">
    <input type="password" name="password" placeholder="Mot de passe" autofocus>
    <button type="submit">Connexion</button>
  </form>
</div>
</body>
</html>"""


def init_dashboard(memory, regime=None, **kwargs):
    global _memory, _regime
    _memory  = memory
    _regime  = regime

@app.route("/api/stats")
def api_stats():
    if not _memory: return jsonify({})
    return jsonify(_memory.compute_performance_stats())

@app.route("/api/stats/periods")
def api_stats_periods():
    from flask import request as flask_req
    if not _memory:
        return jsonify({})
    expert = flask_req.args.get("expert", "all")
    try:
        conn = sqlite3.connect(_memory.db_path, timeout=5)

        src_filter = ""
        if expert == "gap":
            src_filter = "AND json_extract(market_context, '$.strategy_source') = 'gapper'"
        elif expert == "geo":
            src_filter = "AND json_extract(market_context, '$.strategy_source') = 'geo_v4'"

        def _pstats(since):
            date_clause = f"AND exit_at >= '{since}'" if since else ""
            rows = conn.execute(f"""
                SELECT pnl FROM trades
                WHERE status = 'closed'
                  AND (close_reason IS NULL
                       OR close_reason NOT IN ('position_reconciled', 'synced_close'))
                  AND (json_extract(market_context, '$.source') IS NULL
                       OR json_extract(market_context, '$.source')
                          NOT IN ('order_sync', 'order_sync_synthetic'))
                  {src_filter}
                  {date_clause}
            """).fetchall()
            pnls   = [r[0] for r in rows if r[0] is not None]
            wins   = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p <= 0]
            total  = len(pnls)
            return {
                "trades":   total,
                "wins":     len(wins),
                "losses":   len(losses),
                "win_rate": round(len(wins) / total * 100, 1) if total else None,
                "pnl":      round(sum(pnls), 4) if pnls else 0.0,
            }

        result = {
            "week":  _pstats(_period_start("week")),
            "month": _pstats(_period_start("month")),
            "ytd":   _pstats(_period_start("ytd")),
            "all":   _pstats(None),
        }
        conn.close()
        return jsonify(result)
    except Exception as e:
        logger.error(f"api_stats_periods error: {e}")
        return jsonify({"error": str(e)})

@app.route("/api/trades/open")
def api_open_trades():
    if not _memory: return jsonify([])
    trades = _memory.get_open_trades()
    for t in trades:
        raw = t.get("market_context") or {}
        if isinstance(raw, str):
            try: raw = json.loads(raw)
            except: raw = {}
        t["strategy_source"] = raw.get("strategy_source")
        t["deployed"] = round(
            float(t.get("entry_price") or 0) * float(t.get("qty") or 0), 2
        )
    return jsonify(trades)

@app.route("/api/trades/recent")
def api_recent_trades():
    if not _memory: return jsonify([])
    return jsonify(_memory.get_recent_trades(limit=20))

@app.route("/api/decisions/recent")
def api_recent_decisions():
    if not _memory: return jsonify([])
    decisions = _memory.get_recent_decisions(limit=15)
    for d in decisions:
        md = d.get("market_data")
        try:
            ctx = json.loads(md) if isinstance(md, str) else (md or {})
            d["strategy_source"] = ctx.get("strategy_source")
        except Exception:
            d["strategy_source"] = None
    return jsonify(decisions)

@app.route("/api/analyses/recent")
def api_recent_analyses():
    if not _memory: return jsonify([])
    analyses = _memory.get_analyses(limit=5)
    for a in analyses:
        for field in ["lessons","mistakes"]:
            if a.get(field) and isinstance(a[field], str):
                try: a[field] = json.loads(a[field])
                except: pass
    return jsonify(analyses)

@app.route("/api/anomalies")
def api_anomalies():
    return jsonify([])

@app.route("/api/movers")
def api_movers():
    return jsonify({"movers": [], "note": "geo-only mode"})

@app.route("/api/sentiment")
def api_sentiment():
    return jsonify({"sentiment": "neutral", "score": 0, "headlines": [], "alerts": []})

@app.route("/api/calendar")
def api_calendar():
    return jsonify({"event": None, "note": ""})

@app.route("/api/regime")
def api_regime():
    if not _regime:
        return jsonify({"regime": "UNKNOWN", "vix": None})
    try:
        cache = _regime.get_cache()
        return jsonify({
            "regime": cache.get("regime", "UNKNOWN").upper(),
            "vix":    cache.get("vix"),
        })
    except Exception as e:
        return jsonify({"regime": "UNKNOWN", "error": str(e)})

def _period_start(period: str) -> str | None:
    now = datetime.now(timezone.utc)
    if period == "today":
        return now.date().isoformat()
    if period == "week":
        monday = now.date() - __import__('datetime').timedelta(days=now.weekday())
        return monday.isoformat()
    if period == "month":
        return now.date().replace(day=1).isoformat()
    if period == "ytd":
        return now.date().replace(month=1, day=1).isoformat()
    return None  # all

@app.route("/api/closed-today")
def api_closed_today():
    from flask import request as flask_req
    if not _memory:
        return jsonify({"closed": [], "date": ""})
    try:
        period    = flask_req.args.get("period", "today")
        since     = _period_start(period)
        today     = datetime.now(timezone.utc).date().isoformat()
        conn      = sqlite3.connect(_memory.db_path, timeout=10)
        c         = conn.cursor()
        if since:
            c.execute("""
                SELECT symbol,
                       SUM(pnl)         AS total_pnl,
                       COUNT(*)         AS trade_count,
                       SUM(qty)         AS total_qty_sold,
                       MAX(exit_at)     AS last_exit_at,
                       GROUP_CONCAT(DISTINCT close_reason) AS reasons
                FROM trades
                WHERE status = 'closed'
                  AND (close_reason IS NULL OR close_reason != 'position_reconciled')
                  AND exit_at >= ?
                GROUP BY symbol
                ORDER BY MAX(exit_at) DESC
            """, (since,))
        else:
            c.execute("""
                SELECT symbol,
                       SUM(pnl)         AS total_pnl,
                       COUNT(*)         AS trade_count,
                       SUM(qty)         AS total_qty_sold,
                       MAX(exit_at)     AS last_exit_at,
                       GROUP_CONCAT(DISTINCT close_reason) AS reasons
                FROM trades
                WHERE status = 'closed'
                  AND (close_reason IS NULL OR close_reason != 'position_reconciled')
                GROUP BY symbol
                ORDER BY MAX(exit_at) DESC
            """)
        rows = c.fetchall()
        conn.close()
        closed = [
            {
                "symbol":      r[0],
                "pnl":         round(r[1], 6) if r[1] is not None else 0,
                "trade_count": r[2],
                "qty_sold":    round(r[3], 8) if r[3] is not None else 0,
                "last_exit":   r[4] or "",
                "reasons":     r[5] or "",
            }
            for r in rows
        ]
        return jsonify({"closed": closed, "date": today, "period": period})
    except Exception as e:
        logger.error(f"api_closed_today error: {e}")
        return jsonify({"closed": [], "error": str(e)})

@app.route("/api/trades/individual")
def api_trades_individual():
    from flask import request as flask_req
    if not _memory:
        return jsonify({"trades": []})
    try:
        period = flask_req.args.get("period", "today")
        since  = _period_start(period)
        limit  = min(int(flask_req.args.get("limit", 300)), 500)
        conn   = sqlite3.connect(_memory.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        if since:
            c.execute("""
                SELECT trade_id, symbol, side, qty, entry_price, exit_price,
                       pnl, pnl_pct, hold_duration_min,
                       close_reason, entry_at, exit_at,
                       entry_snapshot, exit_vs_target, market_context
                FROM trades
                WHERE status = 'closed'
                  AND exit_at >= ?
                ORDER BY exit_at DESC LIMIT ?
            """, (since, limit))
        else:
            c.execute("""
                SELECT trade_id, symbol, side, qty, entry_price, exit_price,
                       pnl, pnl_pct, hold_duration_min,
                       close_reason, entry_at, exit_at,
                       entry_snapshot, exit_vs_target, market_context
                FROM trades
                WHERE status = 'closed'
                ORDER BY exit_at DESC LIMIT ?
            """, (limit,))
        rows = c.fetchall()
        conn.close()
        trades = []
        for r in rows:
            snap = {}
            if r["entry_snapshot"]:
                try:
                    snap = json.loads(r["entry_snapshot"])
                except Exception:
                    snap = {}
            mc = {}
            if r["market_context"]:
                try:
                    mc = json.loads(r["market_context"])
                except Exception:
                    mc = {}
            geo_ctx = None
            if mc.get("strategy_source") == "geometric":
                raw_atr = mc.get("atr")
                geo_ctx = {
                    "confluence":     mc.get("confluence"),
                    "structure":      mc.get("structure"),
                    "rsi_divergence": mc.get("rsi_divergence"),
                    "atr":            round(float(raw_atr), 6) if raw_atr is not None else None,
                    "target_midpoint": mc.get("target_midpoint"),
                    "patterns":       mc.get("patterns") or [],
                    "level":          mc.get("level"),
                }
            trades.append({
                "trade_id":       r["trade_id"],
                "symbol":         r["symbol"],
                "side":           r["side"],
                "qty":            round(r["qty"], 8) if r["qty"] else 0,
                "entry_price":    r["entry_price"],
                "exit_price":     r["exit_price"],
                "pnl":            round(r["pnl"], 6)    if r["pnl"]     is not None else None,
                "pnl_pct":        round(r["pnl_pct"], 4) if r["pnl_pct"] is not None else None,
                "hold_min":       round(r["hold_duration_min"], 1) if r["hold_duration_min"] else None,
                "close_reason":   r["close_reason"],
                "entry_at":       r["entry_at"],
                "exit_at":        r["exit_at"],
                "exit_vs_target": r["exit_vs_target"],
                "strategy_source": mc.get("strategy_source"),
                "geo_context":     geo_ctx,
            })
        return jsonify({"trades": trades, "period": period})
    except Exception as e:
        logger.error(f"api_trades_individual error: {e}")
        return jsonify({"trades": [], "error": str(e)})

@app.route("/api/trades/<trade_id>")
def api_trade_detail(trade_id):
    if not _memory:
        return jsonify({"error": "not ready"}), 503
    try:
        conn = sqlite3.connect(_memory.db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        trade = conn.execute("""
            SELECT trade_id, symbol, side, qty, entry_price, exit_price,
                   pnl, pnl_pct, hold_duration_min, close_reason,
                   entry_at, exit_at, stop_loss, take_profit,
                   exit_vs_target, market_context
            FROM trades WHERE trade_id = ?
        """, (trade_id,)).fetchone()
        if not trade:
            conn.close()
            return jsonify({"error": "not found"}), 404
        analysis = conn.execute("""
            SELECT outcome, pnl, analysis, lessons, mistakes
            FROM trade_analyses WHERE trade_id = ?
            ORDER BY rowid DESC LIMIT 1
        """, (trade_id,)).fetchone()
        conn.close()
        mc = {}
        try: mc = json.loads(trade["market_context"] or "{}")
        except: pass
        geo = None
        if mc.get("strategy_source") == "geometric":
            geo = {
                "confluence":      mc.get("confluence"),
                "structure":       mc.get("structure"),
                "rsi_divergence":  mc.get("rsi_divergence"),
                "atr":             mc.get("atr"),
                "target_midpoint": mc.get("target_midpoint"),
                "patterns":        mc.get("patterns") or [],
                "level":           mc.get("level"),
                "side":            mc.get("side"),
            }
        return jsonify({
            "trade_id":        trade["trade_id"],
            "symbol":          trade["symbol"],
            "side":            trade["side"],
            "qty":             trade["qty"],
            "entry_price":     trade["entry_price"],
            "exit_price":      trade["exit_price"],
            "pnl":             trade["pnl"],
            "pnl_pct":         trade["pnl_pct"],
            "hold_min":        trade["hold_duration_min"],
            "close_reason":    trade["close_reason"],
            "entry_at":        trade["entry_at"],
            "exit_at":         trade["exit_at"],
            "stop_loss":       trade["stop_loss"],
            "take_profit":     trade["take_profit"],
            "exit_vs_target":  trade["exit_vs_target"],
            "strategy_source": mc.get("strategy_source"),
            "geo_context":     geo,
            "analysis": {
                "outcome":  analysis["outcome"],
                "text":     analysis["analysis"],
                "lessons":  analysis["lessons"],
                "mistakes": analysis["mistakes"],
            } if analysis else None,
        })
    except Exception as e:
        logger.error(f"api_trade_detail error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/analysis")
def api_analysis():
    if not _memory:
        return jsonify({})
    try:
        conn = sqlite3.connect(_memory.db_path, timeout=10)
        c    = conn.cursor()

        # ── Expert filter — based on strategy_source in market_context ──
        expert = request.args.get("expert", "all").lower()
        if expert == "gap":
            ef = "AND json_extract(market_context, '$.strategy_source') = 'gapper'"
        elif expert == "geo":
            ef = "AND json_extract(market_context, '$.strategy_source') = 'geo_v4'"
        else:
            ef = ""

        # ── All closed trades ──────────────────────────────────────────
        c.execute(f"""
            SELECT symbol, pnl, pnl_pct, hold_duration_min, close_reason, exit_at
            FROM trades WHERE status='closed' {ef}
            ORDER BY exit_at
        """)
        trades = c.fetchall()

        # ── Daily P&L (last 30 days) ───────────────────────────────────
        c.execute(f"""
            SELECT DATE(exit_at) AS day, SUM(pnl) AS day_pnl, COUNT(*) AS cnt
            FROM trades WHERE status='closed' {ef}
            GROUP BY day ORDER BY day DESC LIMIT 30
        """)
        daily_rows = c.fetchall()

        # ── P&L by asset ───────────────────────────────────────────────
        c.execute(f"""
            SELECT symbol, SUM(pnl) AS total, COUNT(*) AS cnt,
                   AVG(pnl) AS avg_pnl, AVG(hold_duration_min) AS avg_hold
            FROM trades WHERE status='closed' {ef}
            GROUP BY symbol ORDER BY total DESC
        """)
        asset_rows = c.fetchall()

        # ── Close reason breakdown ─────────────────────────────────────
        c.execute(f"""
            SELECT close_reason, COUNT(*) AS cnt, SUM(pnl) AS total_pnl
            FROM trades WHERE status='closed' {ef}
            GROUP BY close_reason ORDER BY cnt DESC
        """)
        reason_rows = c.fetchall()

        conn.close()

        # ── Compute core metrics ───────────────────────────────────────
        total  = len(trades)
        wins   = [t for t in trades if (t[1] or 0) > 0]
        losses = [t for t in trades if (t[1] or 0) < 0]
        pnls   = [t[1] or 0 for t in trades]
        holds  = [t[3] or 0 for t in trades if t[3]]

        gross_win  = sum(t[1] for t in wins)  if wins   else 0
        gross_loss = sum(t[1] for t in losses) if losses else 0
        win_rate   = (len(wins) / total * 100) if total else 0
        loss_rate  = 100 - win_rate
        avg_win    = (gross_win / len(wins))   if wins   else 0
        avg_loss   = (gross_loss / len(losses)) if losses else 0
        pf         = (gross_win / abs(gross_loss)) if gross_loss else 999
        expectancy = (win_rate/100 * avg_win) + (loss_rate/100 * avg_loss)

        best_trade  = max(trades, key=lambda t: t[1] or 0) if trades else None
        worst_trade = min(trades, key=lambda t: t[1] or 0) if trades else None
        avg_hold    = (sum(holds) / len(holds)) if holds else 0

        # ── Streak calculation ─────────────────────────────────────────
        streak, max_win_streak, max_loss_streak = 0, 0, 0
        cur_streak_type = None
        for t in trades:
            is_win = (t[1] or 0) >= 0
            if cur_streak_type is None or is_win == cur_streak_type:
                streak += 1
                cur_streak_type = is_win
            else:
                if cur_streak_type:
                    max_win_streak  = max(max_win_streak, streak)
                else:
                    max_loss_streak = max(max_loss_streak, streak)
                streak = 1
                cur_streak_type = is_win
        if cur_streak_type is True:
            max_win_streak  = max(max_win_streak, streak)
        elif cur_streak_type is False:
            max_loss_streak = max(max_loss_streak, streak)
        current_streak      = {"type": "win" if cur_streak_type else "loss", "count": streak} if trades else None

        # ── Avg trades per active day ──────────────────────────────────
        active_days = len(set(t[5][:10] for t in trades if t[5])) if trades else 1
        avg_trades_per_day = total / active_days if active_days else 0

        return jsonify({
            "total_trades":      total,
            "winning_trades":    len(wins),
            "losing_trades":     len(losses),
            "win_rate":          round(win_rate, 1),
            "profit_factor":     round(pf, 2) if pf != 999 else 999,
            "expectancy":        round(expectancy, 4),
            "gross_win":         round(gross_win, 4),
            "gross_loss":        round(gross_loss, 4),
            "total_pnl":         round(sum(pnls), 4),
            "avg_win":           round(avg_win, 4),
            "avg_loss":          round(avg_loss, 4),
            "avg_hold_min":      round(avg_hold, 1),
            "avg_trades_per_day": round(avg_trades_per_day, 1),
            "best_trade":  {"symbol": best_trade[0],  "pnl": round(best_trade[1],4),  "reason": best_trade[4]} if best_trade  else None,
            "worst_trade": {"symbol": worst_trade[0], "pnl": round(worst_trade[1],4), "reason": worst_trade[4]} if worst_trade else None,
            "current_streak":    current_streak,
            "max_win_streak":    max_win_streak,
            "max_loss_streak":   max_loss_streak,
            "daily_pnl":  [{"date": r[0], "pnl": round(r[1],4), "trades": r[2]} for r in daily_rows],
            "by_asset":   [{"symbol": r[0], "pnl": round(r[1],4), "trades": r[2], "avg_pnl": round(r[3],4), "avg_hold_min": round(r[4] or 0,1)} for r in asset_rows],
            "by_reason":  [{"reason": r[0], "trades": r[1], "pnl": round(r[2],4)} for r in reason_rows],
        })
    except Exception as e:
        logger.error(f"api_analysis error: {e}")
        return jsonify({"error": str(e)})


# ── Helpers communs pour les 4 endpoints Analysis Geo V4 ──────────────────────
_GEO_V4_SRC = "json_extract(market_context, '$.strategy_source') = 'geo_v4'"
_GEO_EXCLUDE = "close_reason NOT IN ('synced_close', 'orphan_close', 'position_reconciled')"

def _geo_filter(extra: str = "") -> str:
    """Clause WHERE complète pour trades geo_v4 depuis GEO_RESET_DATE."""
    return (
        f"status = 'closed' "
        f"AND exit_at >= '{config.GEO_RESET_DATE}' "
        f"AND {_GEO_V4_SRC} "
        f"AND {_GEO_EXCLUDE} "
        f"{extra}"
    )

def _categorise_reason(r: str) -> str:
    r = (r or "").lower()
    if any(k in r for k in ("stop", "sl_", "stop_loss")):
        return "stop"
    if any(k in r for k in ("target", "tp", "profit", "take_profit")):
        return "target"
    if any(k in r for k in ("timeout", "time", "expir", "max_hold")):
        return "timeout"
    return "other"


@app.route("/api/analysis/rolling")
def api_analysis_rolling():
    """Section 1 — Rolling stats des 30 derniers trades geo_v4."""
    if not _memory:
        return jsonify({"n_trades": 0})
    try:
        conn = sqlite3.connect(_memory.db_path, timeout=5)
        rows = conn.execute(f"""
            SELECT pnl, hold_duration_min FROM trades
            WHERE {_geo_filter()}
            ORDER BY exit_at DESC LIMIT 30
        """).fetchall()
        conn.close()
        pnls  = [r[0] or 0 for r in rows]
        holds = [r[1] for r in rows if r[1] is not None]
        wins  = [p for p in pnls if p > 0]
        losses= [p for p in pnls if p < 0]
        total = len(pnls)
        pf    = round(sum(wins) / abs(sum(losses)), 2) if losses else 999
        return jsonify({
            "n_trades":      total,
            "win_rate":      round(len(wins) / total * 100, 1) if total else 0,
            "profit_factor": pf,
            "avg_hold_min":  round(sum(holds) / len(holds), 1) if holds else 0,
        })
    except Exception as e:
        logger.error(f"api_analysis_rolling error: {e}")
        return jsonify({"error": str(e), "n_trades": 0})


@app.route("/api/analysis/exits")
def api_analysis_exits():
    """Section 2 — Breakdown par type de sortie (stop/target/timeout)."""
    if not _memory:
        return jsonify({"total": 0})
    try:
        conn = sqlite3.connect(_memory.db_path, timeout=5)
        rows = conn.execute(f"""
            SELECT close_reason, COUNT(*) as n FROM trades
            WHERE {_geo_filter()}
            GROUP BY close_reason
        """).fetchall()
        conn.close()
        cats = {"stop": 0, "target": 0, "timeout": 0, "other": 0}
        for reason, cnt in rows:
            cats[_categorise_reason(reason)] += cnt
        total = sum(cats.values())
        def pct(n): return round(n / total * 100, 1) if total else 0
        return jsonify({
            "total":   total,
            "stop":    {"n": cats["stop"],    "pct": pct(cats["stop"])},
            "target":  {"n": cats["target"],  "pct": pct(cats["target"])},
            "timeout": {"n": cats["timeout"], "pct": pct(cats["timeout"])},
            "other":   {"n": cats["other"],   "pct": pct(cats["other"])},
        })
    except Exception as e:
        logger.error(f"api_analysis_exits error: {e}")
        return jsonify({"error": str(e), "total": 0})


@app.route("/api/analysis/period")
def api_analysis_period():
    """Section 3 — Stats par période : 7d / mtd / all."""
    if not _memory:
        return jsonify({"n_trades": 0})
    period = request.args.get("period", "all")
    try:
        from datetime import timedelta
        now   = datetime.now(timezone.utc).date()
        since = None
        if period == "7d":
            since = (now - timedelta(days=7)).isoformat()
        elif period == "mtd":
            since = now.replace(day=1).isoformat()
        # "all" → already covered by _geo_filter (>= GEO_RESET_DATE)
        extra = f"AND exit_at >= '{since}'" if since else ""
        conn  = sqlite3.connect(_memory.db_path, timeout=5)
        rows  = conn.execute(f"""
            SELECT pnl FROM trades WHERE {_geo_filter(extra)}
        """).fetchall()
        conn.close()
        pnls  = [r[0] or 0 for r in rows]
        wins  = [p for p in pnls if p > 0]
        losses= [p for p in pnls if p < 0]
        total = len(pnls)
        pf    = round(sum(wins) / abs(sum(losses)), 2) if losses else 999
        return jsonify({
            "period":        period,
            "n_trades":      total,
            "total_pnl":     round(sum(pnls), 2),
            "win_rate":      round(len(wins) / total * 100, 1) if total else 0,
            "profit_factor": pf,
        })
    except Exception as e:
        logger.error(f"api_analysis_period error: {e}")
        return jsonify({"error": str(e), "n_trades": 0})


@app.route("/api/analysis/equity-curve")
def api_analysis_equity_curve():
    """Section 4 — Courbe d'équité cumulée depuis GEO_RESET_DATE."""
    if not _memory:
        return jsonify({"capital_start": 0, "points": []})
    try:
        capital_start = _get_alpaca_equity()
        conn  = sqlite3.connect(_memory.db_path, timeout=5)
        rows  = conn.execute(f"""
            SELECT exit_at, pnl FROM trades
            WHERE {_geo_filter()}
            ORDER BY exit_at
        """).fetchall()
        conn.close()
        points     = []
        cumulative = capital_start
        for exit_at, pnl in rows:
            cumulative += (pnl or 0)
            points.append({
                "date":    (exit_at or "")[:10],
                "capital": round(cumulative, 2),
            })
        return jsonify({
            "capital_start": round(capital_start, 2),
            "capital_now":   round(cumulative, 2),
            "points":        points,
        })
    except Exception as e:
        logger.error(f"api_analysis_equity_curve error: {e}")
        return jsonify({"capital_start": 0, "points": [], "error": str(e)})


@app.route("/api/account")
def api_account():
    try:
        import alpaca_trade_api as tradeapi
        api = tradeapi.REST(
            os.getenv("ALPACA_API_KEY"), os.getenv("ALPACA_SECRET_KEY"),
            "https://paper-api.alpaca.markets"
        )
        account = api.get_account()
        return jsonify({
            "equity":          float(account.equity),
            "cash":            float(account.cash),
            "buying_power":    float(account.buying_power),
            "portfolio_value": float(account.portfolio_value),
            "last_equity":     float(account.last_equity),
        })
    except Exception as e:
        logger.error(f"api_account error: {e}")
        return jsonify({"equity": 0, "cash": 0, "buying_power": 0, "portfolio_value": 0, "error": str(e)})

@app.route("/api/orders/pending")
def api_orders_pending():
    try:
        import alpaca_trade_api as tradeapi
        api = tradeapi.REST(
            os.getenv("ALPACA_API_KEY"), os.getenv("ALPACA_SECRET_KEY"),
            "https://paper-api.alpaca.markets"
        )
        orders = api.list_orders(status="open")
        result = []
        for o in orders:
            qty        = float(o.qty or 0)
            lim        = float(o.limit_price) if o.limit_price else None
            est_value  = round(qty * lim, 2) if lim else None
            result.append({
                "id":              o.id,
                "symbol":          o.symbol,
                "side":            o.side,
                "qty":             qty,
                "limit_price":     lim,
                "estimated_value": est_value,
                "status":          o.status,
                "created_at":      str(o.created_at),
                "time_in_force":   o.time_in_force,
            })
        return jsonify(result)
    except Exception as e:
        logger.error(f"api_orders_pending error: {e}")
        return jsonify([])

@app.route("/api/stops")
def api_stops():
    try:
        import sqlite3 as _sq
        conn = _sq.connect(_memory.db_path, timeout=3)
        rows = conn.execute(
            "SELECT symbol, stop_loss FROM trades WHERE status='open' AND stop_loss IS NOT NULL"
        ).fetchall()
        conn.close()
        stops = {r[0]: float(r[1]) for r in rows if r[1]}
        return jsonify({"stops": stops})
    except Exception as e:
        logger.error(f"api_stops error: {e}")
        return jsonify({"stops": {}})

@app.route("/api/health")
def api_health():
    return jsonify({"status":"ok","timestamp":datetime.now(timezone.utc).isoformat()})

@app.route("/")
def dashboard():
    return render_template_string(DASHBOARD_HTML)


# ── Cache equity Alpaca (évite d'appeler l'API à chaque request) ──────────────
_equity_cache: dict = {"value": None, "ts": 0.0}
_EQUITY_CACHE_TTL = 60  # secondes

def _get_alpaca_equity() -> float:
    """Retourne l'equity réelle du compte Alpaca paper, avec cache 60s."""
    import time as _time
    now = _time.time()
    if _equity_cache["value"] is not None and now - _equity_cache["ts"] < _EQUITY_CACHE_TTL:
        return _equity_cache["value"]
    try:
        import alpaca_trade_api as tradeapi
        api = tradeapi.REST(
            os.getenv("ALPACA_API_KEY"), os.getenv("ALPACA_SECRET_KEY"),
            "https://paper-api.alpaca.markets"
        )
        equity = float(api.get_account().equity)
        _equity_cache["value"] = equity
        _equity_cache["ts"]    = now
        return equity
    except Exception as e:
        logger.warning(f"_get_alpaca_equity error: {e}")
        # Retourne la valeur cachée même périmée, ou GEO_CAPITAL par défaut
        return _equity_cache["value"] if _equity_cache["value"] else config.GEO_CAPITAL


@app.route("/api/experts/stats")
def api_experts_stats():
    """Geo-Only ETH — capital et stats de la stratégie geo_v4.
    capital_start = equity réelle Alpaca (nouveau départ GEO_RESET_DATE).
    Seuls les trades APRÈS GEO_RESET_DATE entrent dans le calcul P&L.
    """
    if not _memory:
        return jsonify({})
    try:
        import json as _json
        from datetime import datetime as _dt
        EXCLUDE = ("synced_close", "orphan_close", "position_reconciled")

        # ── Capital de référence (fixe au reset) et equity live Alpaca ─────────
        capital_start = config.GEO_CAPITAL          # valeur fixe au moment du reset
        capital_now   = _get_alpaca_equity()         # equity Alpaca live — source de vérité

        # ── Trades geo_v4 — uniquement APRÈS GEO_RESET_DATE ─────────────────
        all_trades = _memory.get_recent_trades(limit=500)
        geo_trades = []
        for t in all_trades:
            ctx = t.get("market_context") or {}
            if isinstance(ctx, str):
                try: ctx = _json.loads(ctx)
                except: ctx = {}
            if ctx.get("strategy_source") != "geo_v4":
                continue
            # Filtre date de reset
            created = t.get("created_at") or t.get("entry_time") or ""
            if created and str(created)[:10] < config.GEO_RESET_DATE:
                continue
            geo_trades.append(t)

        closed = [t for t in geo_trades if t.get("status") == "closed"
                  and t.get("close_reason") not in EXCLUDE]
        pnls   = [t.get("pnl") or 0 for t in closed]
        wins   = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        pf     = round(sum(wins) / abs(sum(losses)), 2) if losses else 999

        deployed = sum(
            float(t.get("entry_price", 0)) * float(t.get("qty", 0))
            for t in geo_trades if t.get("status") == "open"
        )
        total_pnl     = round(sum(pnls), 4)
        capital_return = round((capital_now - capital_start) / capital_start * 100, 2) if capital_start else 0

        return jsonify({
            "geo_v4": {
                "total_trades":    len(closed),
                "total_pnl":       total_pnl,
                "win_rate":        round(len(wins) / len(pnls) * 100, 1) if pnls else 0,
                "profit_factor":   pf,
                "avg_win":         round(sum(wins) / len(wins), 4) if wins else 0,
                "avg_loss":        round(sum(losses) / len(losses), 4) if losses else 0,
                "capital_start":   round(capital_start, 2),
                "capital_now":     round(capital_now, 2),
                "capital_return":  capital_return,
                "open_trades":     len([t for t in geo_trades if t.get("status") == "open"]),
                "live_unrealized": 0.0,
                "deployed":        round(deployed, 2),
            }
        })
    except Exception as e:
        logger.error(f"api_experts_stats error: {e}")
        return jsonify({"error": str(e)})

def start_dashboard(memory, regime=None, port=8080, **kwargs):
    import subprocess, time as _time
    init_dashboard(memory, regime=regime)
    # Release port from any lingering previous process (daemon thread didn't exit fast enough)
    try:
        subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True, timeout=3)
        _time.sleep(0.5)
    except Exception:
        pass
    def run():
        app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    logger.info(f"🌐 Dashboard running on port {port}")
    return thread

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TRADING AGENT</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#080c10;--surface:#0d1117;--border:#1a2030;--text:#c8d6e5;--muted:#4a5568;--green:#00ff88;--red:#ff3860;--blue:#4fc3f7;--mono:'Space Mono',monospace;--display:'Syne',sans-serif}
body{background:var(--bg);color:var(--text);font-family:var(--mono);font-size:12px;line-height:1.6}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,136,0.015) 2px,rgba(0,255,136,0.015) 4px);pointer-events:none;z-index:9999}
header{display:flex;justify-content:space-between;align-items:center;padding:16px 24px;border-bottom:1px solid var(--border);background:var(--surface);position:sticky;top:0;z-index:100}
.logo{font-family:var(--display);font-size:18px;font-weight:800;letter-spacing:0.15em;color:var(--green);text-transform:uppercase}
.logo span{color:var(--muted);font-weight:400}
.status-dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}
#clock{color:var(--muted);font-size:11px}
.stats-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:1px;background:var(--border)}
.stat-card{background:var(--surface);padding:20px 16px;text-align:center}
.stat-label{font-size:9px;letter-spacing:0.15em;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
.stat-value{font-family:var(--display);font-size:28px;font-weight:800;line-height:1}
.pos{color:var(--green)} .neg{color:var(--red)} .neu{color:var(--blue)}
.main{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1px;background:var(--border)}
.panel{background:var(--surface);padding:20px;overflow:hidden}
.panel-full{grid-column:1/-1} .panel-half{grid-column:span 2}
.panel-title{font-family:var(--display);font-size:10px;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;color:var(--muted);margin-bottom:16px;display:flex;align-items:center;gap:8px}
.panel-title::after{content:'';flex:1;height:1px;background:var(--border)}
.data-table{width:100%;border-collapse:collapse}
.data-table th{font-size:9px;letter-spacing:0.12em;text-transform:uppercase;color:var(--muted);text-align:left;padding:6px 8px;border-bottom:1px solid var(--border)}
.data-table td{padding:8px;border-bottom:1px solid rgba(26,32,48,0.5)}
.tag{display:inline-block;padding:2px 7px;border-radius:3px;font-size:10px;font-weight:700}
.tag-buy{background:rgba(0,255,136,0.1);color:var(--green)}
.tag-sell{background:rgba(255,56,96,0.1);color:var(--red)}
.tag-open{background:rgba(79,195,247,0.1);color:var(--blue)}
.asset-bars{display:flex;flex-direction:column;gap:10px}
.asset-row{display:flex;align-items:center;gap:10px}
.asset-name{width:70px;font-size:11px;flex-shrink:0}
.bar-wrap{flex:1;height:14px;background:var(--bg);border-radius:2px;overflow:hidden}
.bar-fill{height:100%;border-radius:2px;transition:width 0.8s ease}
.bar-fill.pos{background:linear-gradient(90deg,#00cc6a,var(--green))}
.bar-fill.neg{background:linear-gradient(90deg,#cc2040,var(--red))}
.asset-pnl{width:60px;text-align:right;font-size:11px;flex-shrink:0}
.decision-item{padding:12px 0;border-bottom:1px solid var(--border)}
.decision-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.decision-time{font-size:10px;color:var(--muted)}
.decision-reasoning{font-size:11px;color:var(--muted);line-height:1.5;max-height:3.5em;overflow:hidden;cursor:pointer}
.decision-reasoning.expanded{max-height:200px}
.analysis-item{background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:14px;margin-bottom:10px}
.analysis-text{font-size:11px;color:var(--muted);line-height:1.6;margin-bottom:8px}
.lesson{font-size:10px;color:var(--blue);padding-left:12px;position:relative;margin-bottom:4px}
.lesson::before{content:'→';position:absolute;left:0;color:var(--muted)}
.empty{text-align:center;color:var(--muted);padding:30px;font-size:11px}
.alert-box{background:rgba(255,56,96,0.1);border:1px solid var(--red);border-radius:4px;padding:10px 16px;color:var(--red);font-size:11px;margin-bottom:12px}
.refresh-bar{height:2px;background:var(--border);width:100%;position:fixed;bottom:0;left:0}
.refresh-progress{height:100%;background:var(--green);width:0%}
@media(max-width:1024px){.main{grid-template-columns:1fr 1fr}.stats-grid{grid-template-columns:repeat(3,1fr)}.panel-half{grid-column:span 1}}
@media(max-width:640px){.main{grid-template-columns:1fr}.stats-grid{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<header>
  <div class="logo">AGENT<span>/</span>TERMINAL</div>
  <div style="display:flex;align-items:center;gap:20px">
    <div class="status-dot"></div>
    <div id="clock"></div>
  </div>
</header>
<div class="stats-grid">
  <div class="stat-card"><div class="stat-label">P&L Total</div><div class="stat-value" id="kpi-pnl">—</div></div>
  <div class="stat-card"><div class="stat-label">Win Rate</div><div class="stat-value neu" id="kpi-wr">—</div></div>
  <div class="stat-card"><div class="stat-label">Trades</div><div class="stat-value" id="kpi-trades">—</div></div>
  <div class="stat-card"><div class="stat-label">Profit Factor</div><div class="stat-value neu" id="kpi-pf">—</div></div>
  <div class="stat-card"><div class="stat-label">Max Drawdown</div><div class="stat-value neg" id="kpi-dd">—</div></div>
  <div class="stat-card"><div class="stat-label">Positions Open</div><div class="stat-value neu" id="kpi-open">—</div></div>
</div>
<div class="experts-grid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:1px;background:var(--border);margin-bottom:1px">
  <div style="background:var(--surface);padding:20px;text-align:center">
    <div class="stat-label">📐 Capital</div><div class="stat-value pos" id="geo-capital">—</div>
  </div>
  <div style="background:var(--surface);padding:20px;text-align:center">
    <div class="stat-label">Return</div><div class="stat-value pos" id="geo-return">—</div>
  </div>
  <div style="background:var(--surface);padding:20px;text-align:center">
    <div class="stat-label">Trades</div><div class="stat-value neu" id="geo-trades">—</div>
  </div>
  <div style="background:var(--surface);padding:20px;text-align:center">
    <div class="stat-label">Win Rate</div><div class="stat-value neu" id="geo-wr">—</div>
  </div>
  <div style="background:var(--surface);padding:20px;text-align:center">
    <div class="stat-label">Profit Factor</div><div class="stat-value neu" id="geo-pf">—</div>
  </div>
</div>
<div class="main">
  <div class="panel panel-half">
    <div class="panel-title">Positions ouvertes</div>
    <div id="open-trades-container"><div class="empty">Aucune position ouverte</div></div>
  </div>
  <div class="panel">
    <div class="panel-title">P&L par asset</div>
    <div class="asset-bars" id="asset-bars"><div class="empty">Pas de données</div></div>
  </div>
  <div class="panel panel-full">
    <div class="panel-title">Historique des trades</div>
    <div style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Symbol</th><th>Dir.</th><th>Entrée</th><th>Sortie</th><th>Qté</th><th>P&L $</th><th>P&L %</th><th>Durée</th><th>Raison</th><th>Statut</th></tr></thead>
        <tbody id="trades-body"><tr><td colspan="10" class="empty">Chargement...</td></tr></tbody>
      </table>
    </div>
  </div>
  <div class="panel panel-half" style="max-height:500px;overflow-y:auto">
    <div class="panel-title">Décisions de l'agent</div>
    <div id="decisions-container"><div class="empty">Aucune décision</div></div>
  </div>
  <div class="panel" style="max-height:500px;overflow-y:auto">
    <div class="panel-title">Analyses post-trade</div>
    <div id="analyses-container"><div class="empty">Aucune analyse</div></div>
  </div>
</div>
<div class="refresh-bar"><div class="refresh-progress" id="refresh-progress"></div></div>
<script>
const REFRESH=15000;
function fmt(v,p='$',d=2){if(v===null||v===undefined||isNaN(v))return'—';return p+parseFloat(v).toFixed(d)}
function fmtPct(v){if(v===null||v===undefined||isNaN(v))return'—';const n=parseFloat(v);return(n>0?'+':'')+n.toFixed(2)+'%'}
function pnlCls(v){if(!v||isNaN(v))return'';return parseFloat(v)>=0?'pos':'neg'}
function fmtDur(m){if(!m)return'—';const n=Math.round(m);return n<60?n+'min':Math.floor(n/60)+'h'+(n%60>0?n%60+'min':'')}
async function fetchJSON(url){try{const r=await fetch(url);return await r.json()}catch(e){return null}}
function updateClock(){document.getElementById('clock').textContent=new Date().toUTCString().split(' ')[4]+' UTC'}
setInterval(updateClock,1000);updateClock();
async function updateExpertStats() {
  const d = await fetchJSON('/api/experts/stats');
  if (!d) return;
  const geo = d.geo_v4 || {};
  const fmt$ = v => '$' + Math.abs(v).toFixed(2);
  const fmtPct2 = v => (v >= 0 ? '+' : '') + parseFloat(v).toFixed(2) + '%';
  const cap = geo.capital_now ?? 1000;
  const ret = geo.capital_return ?? 0;
  document.getElementById('geo-capital').textContent = fmt$(cap);
  document.getElementById('geo-capital').className = 'stat-value ' + (cap >= 1000 ? 'pos' : 'neg');
  document.getElementById('geo-return').textContent = fmtPct2(ret);
  document.getElementById('geo-return').className = 'stat-value ' + (ret >= 0 ? 'pos' : 'neg');
  document.getElementById('geo-trades').textContent = geo.total_trades ?? 0;
  document.getElementById('geo-wr').textContent = (geo.win_rate ?? 0).toFixed(1) + '%';
  const pf = geo.profit_factor ?? 0;
  document.getElementById('geo-pf').textContent = pf >= 999 ? '∞' : parseFloat(pf).toFixed(2);
  document.getElementById('geo-pf').className = 'stat-value ' + (pf >= 1 ? 'pos' : 'neg');
}
async function updateStats(){
  const s=await fetchJSON('/api/stats');
  if(!s||s.total_trades===0)return;
  const pnl=s.total_pnl||0;
  const el=document.getElementById('kpi-pnl');
  el.textContent=(pnl>=0?'+':'')+' $'+Math.abs(pnl).toFixed(2);
  el.className='stat-value '+(pnl>=0?'pos':'neg');
  document.getElementById('kpi-wr').textContent=(s.win_rate||0).toFixed(1)+'%';
  document.getElementById('kpi-trades').textContent=s.total_trades;
  const pf=document.getElementById('kpi-pf');
  pf.textContent=s.profit_factor>=999?'∞':(s.profit_factor||0).toFixed(2);
  pf.className='stat-value '+((s.profit_factor||0)>=1?'pos':'neg');
  document.getElementById('kpi-dd').textContent='-$'+(s.max_drawdown||0).toFixed(2);
  renderAssetBars(s.asset_pnl||{});
}
async function updateOpenTrades(){
  const trades=await fetchJSON('/api/trades/open');
  const el=document.getElementById('open-trades-container');
  document.getElementById('kpi-open').textContent=trades?trades.length:0;
  if(!trades||trades.length===0){el.innerHTML='<div class="empty">Aucune position ouverte</div>';return}
  el.innerHTML='<table class="data-table"><thead><tr><th>Symbol</th><th>Dir.</th><th>Entrée</th><th>SL</th><th>TP</th></tr></thead><tbody>'+
    trades.map(t=>`<tr><td><strong>${t.symbol}</strong></td><td><span class="tag tag-${t.side}">${t.side.toUpperCase()}</span></td><td>${fmt(t.entry_price)}</td><td style="color:var(--red)">${fmt(t.stop_loss)}</td><td style="color:var(--green)">${fmt(t.take_profit)}</td></tr>`).join('')+
    '</tbody></table>';
}
function renderAssetBars(ap){
  const c=document.getElementById('asset-bars');
  const e=Object.entries(ap);
  if(!e.length){c.innerHTML='<div class="empty">Pas de données</div>';return}
  const max=Math.max(...e.map(([,v])=>Math.abs(v)),1);
  c.innerHTML=e.sort(([,a],[,b])=>b-a).map(([s,p])=>{
    const pct=Math.abs(p)/max*100;const cls=p>=0?'pos':'neg';
    return`<div class="asset-row"><div class="asset-name">${s}</div><div class="bar-wrap"><div class="bar-fill ${cls}" style="width:${pct}%"></div></div><div class="asset-pnl ${cls}">${p>=0?'+':''} $${Math.abs(p).toFixed(2)}</div></div>`;
  }).join('');
}
async function updateTradesHistory(){
  const trades=await fetchJSON('/api/trades/recent');
  const body=document.getElementById('trades-body');
  if(!trades||!trades.length){body.innerHTML='<tr><td colspan="10" class="empty">Aucun trade</td></tr>';return}
  body.innerHTML=trades.map(t=>{
    const pnl=t.pnl;const cls=pnl===null?'':(pnl>=0?'pos':'neg');const isOpen=t.status==='open';
    return`<tr><td><strong>${t.symbol}</strong></td><td><span class="tag tag-${t.side}">${t.side.toUpperCase()}</span></td><td>${fmt(t.entry_price)}</td><td>${isOpen?'<span class="tag tag-open">OUVERT</span>':fmt(t.exit_price)}</td><td>${t.qty}</td><td class="${cls}">${pnl!==null?(pnl>=0?'+':'')+'$'+Math.abs(pnl).toFixed(2):'—'}</td><td class="${cls}">${t.pnl_pct!==null?fmtPct(t.pnl_pct):'—'}</td><td>${fmtDur(t.hold_duration_min)}</td><td style="color:var(--muted)">${t.close_reason||'—'}</td><td><span class="tag ${isOpen?'tag-open':(pnl>=0?'tag-buy':'tag-sell')}">${t.status}</span></td></tr>`;
  }).join('');
}
async function updateDecisions(){
  const d=await fetchJSON('/api/decisions/recent');
  const c=document.getElementById('decisions-container');
  if(!d||!d.length){c.innerHTML='<div class="empty">Aucune décision</div>';return}
  c.innerHTML=d.map(x=>`<div class="decision-item"><div class="decision-header"><span class="tag tag-${x.decision==='buy'?'buy':x.decision==='sell'?'sell':'open'}">${x.decision.toUpperCase()}</span> <strong>${x.symbol||''}</strong><span class="decision-time">${new Date(x.decided_at).toLocaleTimeString('fr-FR')}</span></div><div class="decision-reasoning" onclick="this.classList.toggle('expanded')">${x.reasoning||'—'}</div></div>`).join('');
}
async function updateAnalyses(){
  const a=await fetchJSON('/api/analyses/recent');
  const c=document.getElementById('analyses-container');
  if(!a||!a.length){c.innerHTML='<div class="empty">Aucune analyse</div>';return}
  c.innerHTML=a.map(x=>{
    const lessons=Array.isArray(x.lessons)?x.lessons:[];
    const col=x.outcome==='win'?'var(--green)':x.outcome==='loss'?'var(--red)':'var(--blue)';
    return`<div class="analysis-item"><div style="display:flex;justify-content:space-between;margin-bottom:8px"><strong>${x.symbol}</strong><span style="color:${col};font-weight:700">${x.outcome.toUpperCase()} ${x.pnl?(x.pnl>=0?'+':'')+'$'+Math.abs(x.pnl).toFixed(2):''}</span></div><div class="analysis-text">${x.analysis||'—'}</div>${lessons.map(l=>`<div class="lesson">${l}</div>`).join('')}</div>`;
  }).join('');
}
async function refreshAll(){
  await Promise.all([updateStats(),updateExpertStats(),updateOpenTrades(),updateTradesHistory(),updateDecisions(),updateAnalyses()]);
  const bar=document.getElementById('refresh-progress');
  bar.style.transition='none';bar.style.width='0%';
  requestAnimationFrame(()=>{bar.style.transition=`width ${REFRESH}ms linear`;bar.style.width='100%'});
}
refreshAll();
setInterval(refreshAll,REFRESH);
</script>
</body>
</html>"""
